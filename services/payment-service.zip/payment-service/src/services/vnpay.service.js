const crypto = require('crypto');
const querystring = require('querystring');
const moment = require('moment');

class VNPayService {
  constructor() {
    this.tmnCode = process.env.VNP_TMN_CODE;
    this.secretKey = process.env.VNP_HASH_SECRET;
    this.vnpUrl = process.env.VNP_URL || 'https://sandbox.vnpayment.vn/paymentv2/vpcpay.html';
    this.returnUrl = process.env.VNP_RETURN_URL || 'http://localhost:3000/api/payments/vnpay/callback';
    this.ipnUrl = process.env.VNP_IPN_URL || 'http://localhost:3000/api/payments/vnpay/ipn';
  }

  createPaymentUrl(orderId, amount, orderInfo, ipAddr) {
    const createDate = moment().format('YYYYMMDDHHmmss');
    const txnRef = `${orderId}_${Date.now()}`; // Use orderId with timestamp for uniqueness

    let vnpParams = {
      vnp_Version: '2.1.0',
      vnp_Command: 'pay',
      vnp_TmnCode: this.tmnCode,
      vnp_Amount: Math.round(amount * 100), // VNPay uses smallest currency unit
      vnp_CurrCode: 'VND',
      vnp_TxnRef: txnRef,
      vnp_OrderInfo: orderInfo,
      vnp_OrderType: 'other',
      vnp_Locale: 'vn',
      vnp_ReturnUrl: this.returnUrl,
      vnp_IpnUrl: this.ipnUrl,
      vnp_IpAddr: ipAddr,
      vnp_CreateDate: createDate
      // Removed vnp_BankCode to avoid potential issues
    };

    // Sort params alphabetically (without encoding for signature)
    const sortedParams = this.sortObjectForSignature(vnpParams);

    // Create signature - match official VNPay sample
    const sortedParamsForSig = this.sortObjectForSignature(vnpParams);
    const querystring = require('querystring');
    const signData = querystring.stringify(sortedParamsForSig, { encode: false });
    const hmac = crypto.createHmac('sha512', this.secretKey);
    const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

    // Add signature to params
    vnpParams['vnp_SecureHash'] = signed;

    // Sort again for final URL (with encoding)
    const finalParams = this.sortObject(vnpParams);

    const paymentUrl = this.vnpUrl + '?' + querystring.stringify(finalParams);

    return {
      paymentUrl,
      txnRef
    };
  }

  verifyCallback(vnpParams) {
    const secureHash = vnpParams['vnp_SecureHash'];
    delete vnpParams['vnp_SecureHash'];
    delete vnpParams['vnp_SecureHashType'];

    const sortedParamsForSig = this.sortObjectForSignature(vnpParams);
    const querystring = require('querystring');
    const signData = querystring.stringify(sortedParamsForSig, { encode: false });
    const hmac = crypto.createHmac('sha512', this.secretKey);
    const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

    return secureHash === signed;
  }

  sortObjectForSignature(obj) {
    let sorted = {};
    let str = [];
    let key;
    for (key in obj) {
      if (obj.hasOwnProperty(key)) {
        str.push(encodeURIComponent(key));
      }
    }
    str.sort();
    for (key = 0; key < str.length; key++) {
      sorted[str[key]] = encodeURIComponent(obj[str[key]]).replace(/%20/g, "+");
    }
    return sorted;
  }

  sortObjectForUrl(obj) {
    const sorted = {};
    const keys = Object.keys(obj).sort();
    keys.forEach(key => {
      sorted[key] = encodeURIComponent(obj[key]).replace(/%20/g, '+');
    });
    return sorted;
  }

  sortObject(obj) {
    const sorted = {};
    const keys = Object.keys(obj).sort();
    keys.forEach(key => {
      sorted[key] = encodeURIComponent(obj[key]).replace(/%20/g, '+');
    });
    return sorted;
  }
}

module.exports = new VNPayService();
