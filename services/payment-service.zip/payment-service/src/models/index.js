const PaymentDetail = require('./PaymentDetail');

module.exports = {
  PaymentDetail
};
