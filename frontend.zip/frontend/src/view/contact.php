<?php
$page = 'contact';
include('header.php');
?>

<div class="contact-page">

    <div class="container">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <a href="index.php">Home</a>
            <span>/</span>
            <span class="current">Contact</span>
    </div>

    <div class="wh-box">
        <!-- Main Contact Section -->
        <div class="main-contact-section">
            <h6 class="section-title">ready to work with us</h6>
            
            <div class="contact-content">
                <div class="contact-form-wrapper">
                    <p class="contact-intro">Contact us for all your questions and opinions</p>
                    <div id="form-messages"></div>
                      <form class="contact-form" id="contactForm" method="post">
                        <div class="form-group">
                            <label for="first-name">First Name <span class="required">*</span></label>
                            <input type="text" id="first-name" name="first-name" required>
                        </div>
                        <div class="form-group">
                            <label for="last-name">Last Name <span class="required">*</span></label>
                            <input type="text" id="last-name" name="last-name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address <span class="required">*</span></label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number (Optional)</label>
                            <input type="tel" id="phone" name="phone">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea id="message" name="message" placeholder="Note about your order, e.g. special note for delivery"></textarea>
                        </div>
                        <div class="form-group checkbox-group">
                            <input type="checkbox" id="news-updates" name="news-updates">
                            <label for="news-updates">I want to receive news and updates once in a while. By submitting, I'm agreed to the Terms & Conditons</label>
                        </div>
                        <button type="submit" class="send-message-btn">send message</button>
                    </form>
                </div>
                
                <div class="contact-info-card">

                    <div class="company-info">
                        <h6>Shop365 - e-commerce platform</h6>
                        <p>Address: 19 Nguyễn Hữu Thọ, Tân Phong, Quận 7, Hồ Chí Minh</p>
                        <p>Phone: (012) 3456 789</p>
                        <p>Email: <a class="mail" href= "mailto:contact@shop365.vn">contact@shop365.vn</a></p>
                        
                        <img src="images/logo-modified.png" alt="Shop365 Logo" class="logo">

                        <div class="social-links">
                            <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Map Section -->
        <div class="map-section">
            <h6 class="section-title">find us on google map</h6>
            <div class="google-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d493.59306226752767!2d106.69988048998079!3d10.73179734634149!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752fac2d1f1efb%3A0x602a0eab57824766!2zVMaw4bujbmcgQsOhYyBUw7RuIMSQ4bupYyBUaOG6r25n!5e1!3m2!1svi!2s!4v1744361017597!5m2!1svi!2s" 
                    width="1060" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</div>

</div>
<?php
include('footer.php');
?>
